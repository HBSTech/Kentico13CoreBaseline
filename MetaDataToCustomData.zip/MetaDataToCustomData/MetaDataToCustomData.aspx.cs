﻿using CMS.DocumentEngine;
using CMS.DocumentEngine.Types.Component;
using CMS.DocumentEngine.Types.Generic;
using CMS.WorkflowEngine;
using CMSApp.CMSPages.Custom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CMSApp.CMSPages.Custom
{
    public partial class MetaDataToCustomData : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRun_Click(object sender, EventArgs e)
        {

            string[] ClassNames = new string[] { "Generic.GenericPage", "Generic.Home", "WWWKM.KMPage", "WWWKM.KMPageBlogArticle", "WWWKM.KMPageBlogSummary" };

            foreach (string className in ClassNames)
            {
                foreach (var page in DocumentHelper.GetDocuments(className)
                    .LatestVersion(true)
                    .Published(false)
                    .AllCultures()
                    .TypedResult)
                {
                    string title = string.Empty;
                    string description = string.Empty;
                    string keywords = string.Empty;
                    string thumbnailSmall = string.Empty;
                    string thumbnailLarge = string.Empty;
                    bool? includeInSitemap = null;


                    string dataXml = page.GetValue<string>("Component_PageMetaData", "");
                    if (!string.IsNullOrWhiteSpace(dataXml))
                    {
                        PageTypeComponentDeserializer deserializer = new PageTypeComponentDeserializer();
                        PageMetaData metaData = deserializer.Deserialize<PageMetaData>(dataXml);
                        title = metaData.Title;
                        description = metaData.Description;
                        keywords = metaData.Keywords;
                        thumbnailSmall = metaData.ThumbnailSmall;
                        thumbnailLarge = metaData.ThumbnailLarge;
                    }
                    if (page.GetValue("IncludeInSiteMap") != null)
                    {
                        includeInSitemap = page.GetValue<bool>("IncludeInSiteMap", false);
                    }

                    // Update
                    if (!string.IsNullOrWhiteSpace(title) ||
                        !string.IsNullOrWhiteSpace(description) ||
                        !string.IsNullOrWhiteSpace(keywords) ||
                        !string.IsNullOrWhiteSpace(thumbnailSmall) ||
                        !string.IsNullOrWhiteSpace(thumbnailLarge) ||
                        includeInSitemap.HasValue)
                    {
                        bool wasCheckedIn = !page.IsCheckedOut;
                        bool wasPublished = page.IsPublished;
                        if (!page.IsCheckedOut)
                        {
                            page.CheckOut();
                        }


                        if (!string.IsNullOrWhiteSpace(title))
                        {
                            page.DocumentCustomData.SetValue("MetaData_Title", title);
                        }
                        if (!string.IsNullOrWhiteSpace(description))
                        {
                            page.DocumentCustomData.SetValue("MetaData_Description", description);
                        }
                        if (!string.IsNullOrWhiteSpace(keywords))
                        {
                            page.DocumentCustomData.SetValue("MetaData_Keywords", keywords);
                        }
                        if (!string.IsNullOrWhiteSpace(thumbnailSmall))
                        {
                            page.DocumentCustomData.SetValue("MetaData_ThumbnailSmall", thumbnailSmall);
                        }
                        if (!string.IsNullOrWhiteSpace(thumbnailLarge))
                        {
                            page.DocumentCustomData.SetValue("MetaData_ThumbnailLarge", thumbnailLarge);
                        }
                        if (includeInSitemap.HasValue)
                        {
                            page.NodeCustomData.SetValue("IncludeInSitemap", includeInSitemap.Value);
                        }


                        page.Update();


                        if (wasCheckedIn)
                        {
                            page.CheckIn();
                        }

                        WorkflowInfo workflow = page.GetWorkflow();
                        if (workflow != null && wasPublished)
                        {
                            page.Publish();
                        }
                    }
                }
            }
        }

    }


}