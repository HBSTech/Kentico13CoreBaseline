SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_SKU](
	[SKUID] [int] IDENTITY(1,1) NOT NULL,
	[SKUNumber] [nvarchar](200) NULL,
	[SKUName] [nvarchar](440) NOT NULL,
	[SKUDescription] [nvarchar](max) NULL,
	[SKUPrice] [decimal](18, 9) NOT NULL,
	[SKUEnabled] [bit] NOT NULL,
	[SKUDepartmentID] [int] NULL,
	[SKUManufacturerID] [int] NULL,
	[SKUInternalStatusID] [int] NULL,
	[SKUPublicStatusID] [int] NULL,
	[SKUSupplierID] [int] NULL,
	[SKUAvailableInDays] [int] NULL,
	[SKUGUID] [uniqueidentifier] NOT NULL,
	[SKUImagePath] [nvarchar](450) NULL,
	[SKUWeight] [float] NULL,
	[SKUWidth] [float] NULL,
	[SKUDepth] [float] NULL,
	[SKUHeight] [float] NULL,
	[SKUAvailableItems] [int] NULL,
	[SKUSellOnlyAvailable] [bit] NULL,
	[SKUCustomData] [nvarchar](max) NULL,
	[SKUOptionCategoryID] [int] NULL,
	[SKUOrder] [int] NULL,
	[SKULastModified] [datetime2](7) NOT NULL,
	[SKUCreated] [datetime2](7) NULL,
	[SKUSiteID] [int] NULL,
	[SKUNeedsShipping] [bit] NULL,
	[SKUValidUntil] [datetime2](7) NULL,
	[SKUProductType] [nvarchar](50) NULL,
	[SKUMaxItemsInOrder] [int] NULL,
	[SKUValidity] [nvarchar](50) NULL,
	[SKUValidFor] [int] NULL,
	[SKUMembershipGUID] [uniqueidentifier] NULL,
	[SKUBundleInventoryType] [nvarchar](50) NULL,
	[SKUMinItemsInOrder] [int] NULL,
	[SKURetailPrice] [decimal](18, 9) NULL,
	[SKUParentSKUID] [int] NULL,
	[SKUShortDescription] [nvarchar](max) NULL,
	[SKUEproductFilesCount] [int] NULL,
	[SKUBundleItemsCount] [int] NULL,
	[SKUInStoreFrom] [datetime2](7) NULL,
	[SKUReorderAt] [int] NULL,
	[SKUTrackInventory] [nvarchar](50) NULL,
	[SKUTaxClassID] [int] NULL,
	[SKUBrandID] [int] NULL,
	[SKUCollectionID] [int] NULL,
 CONSTRAINT [PK_COM_SKU] PRIMARY KEY CLUSTERED 
(
	[SKUID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUBrandID] ON [dbo].[COM_SKU]
(
	[SKUBrandID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUCollectionID] ON [dbo].[COM_SKU]
(
	[SKUCollectionID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUDepartmentID] ON [dbo].[COM_SKU]
(
	[SKUDepartmentID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUInternalStatusID] ON [dbo].[COM_SKU]
(
	[SKUInternalStatusID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUManufacturerID] ON [dbo].[COM_SKU]
(
	[SKUManufacturerID] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUName] ON [dbo].[COM_SKU]
(
	[SKUName] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUNumber] ON [dbo].[COM_SKU]
(
	[SKUNumber] ASC
)
WHERE ([SKUNumber] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUOptionCategoryID] ON [dbo].[COM_SKU]
(
	[SKUOptionCategoryID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUParentSKUID] ON [dbo].[COM_SKU]
(
	[SKUParentSKUID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUPrice] ON [dbo].[COM_SKU]
(
	[SKUPrice] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUPublicStatusID] ON [dbo].[COM_SKU]
(
	[SKUPublicStatusID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUSiteID] ON [dbo].[COM_SKU]
(
	[SKUSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUSupplierID] ON [dbo].[COM_SKU]
(
	[SKUSupplierID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_SKU_SKUTaxClassID] ON [dbo].[COM_SKU]
(
	[SKUTaxClassID] ASC
)
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUName]  DEFAULT ('') FOR [SKUName]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUPrice]  DEFAULT ((0)) FOR [SKUPrice]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUEnabled]  DEFAULT ((1)) FOR [SKUEnabled]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [SKUGUID]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUSellOnlyAvailable]  DEFAULT ((0)) FOR [SKUSellOnlyAvailable]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUBundleInventoryType]  DEFAULT ('REMOVEBUNDLE') FOR [SKUBundleInventoryType]
GO
ALTER TABLE [dbo].[COM_SKU] ADD  CONSTRAINT [DEFAULT_COM_SKU_SKUTrackInventory]  DEFAULT (N'ByProduct') FOR [SKUTrackInventory]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUBrandID_COM_Brand] FOREIGN KEY([SKUBrandID])
REFERENCES [dbo].[COM_Brand] ([BrandID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUBrandID_COM_Brand]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUCollectionID_COM_Collection] FOREIGN KEY([SKUCollectionID])
REFERENCES [dbo].[COM_Collection] ([CollectionID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUCollectionID_COM_Collection]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUDepartmentID_COM_Department] FOREIGN KEY([SKUDepartmentID])
REFERENCES [dbo].[COM_Department] ([DepartmentID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUDepartmentID_COM_Department]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUInternalStatusID_COM_InternalStatus] FOREIGN KEY([SKUInternalStatusID])
REFERENCES [dbo].[COM_InternalStatus] ([InternalStatusID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUInternalStatusID_COM_InternalStatus]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUManufacturerID_COM_Manifacturer] FOREIGN KEY([SKUManufacturerID])
REFERENCES [dbo].[COM_Manufacturer] ([ManufacturerID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUManufacturerID_COM_Manifacturer]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUOptionCategoryID_COM_OptionCategory] FOREIGN KEY([SKUOptionCategoryID])
REFERENCES [dbo].[COM_OptionCategory] ([CategoryID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUOptionCategoryID_COM_OptionCategory]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUParentSKUID_COM_SKU] FOREIGN KEY([SKUParentSKUID])
REFERENCES [dbo].[COM_SKU] ([SKUID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUParentSKUID_COM_SKU]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUPublicStatusID_COM_PublicStatus] FOREIGN KEY([SKUPublicStatusID])
REFERENCES [dbo].[COM_PublicStatus] ([PublicStatusID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUPublicStatusID_COM_PublicStatus]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUSiteID_CMS_Site] FOREIGN KEY([SKUSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUSupplierID_COM_Supplier] FOREIGN KEY([SKUSupplierID])
REFERENCES [dbo].[COM_Supplier] ([SupplierID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUSupplierID_COM_Supplier]
GO
ALTER TABLE [dbo].[COM_SKU]  WITH CHECK ADD  CONSTRAINT [FK_COM_SKU_SKUTaxClass_COM_TaxClass] FOREIGN KEY([SKUTaxClassID])
REFERENCES [dbo].[COM_TaxClass] ([TaxClassID])
GO
ALTER TABLE [dbo].[COM_SKU] CHECK CONSTRAINT [FK_COM_SKU_SKUTaxClass_COM_TaxClass]
GO
